#include <iostream>
#include <string>
using namespace std;

// Write concat function here



string &concat(string &a, string b) {
    a += b;
    return a;
}

int main() {
    string first = "Hello ";
    string second = "C++ ";
    string third = "programming";
    concat(concat(first, second), third);

    cout << first << endl;

    return 0;
}