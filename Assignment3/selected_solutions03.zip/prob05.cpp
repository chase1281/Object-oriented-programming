#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class Point {
public:
    int x, y;
};

class LineSegment {
public:
    Point s, t;
    bool is_horizontal() {
        return s.x == t.x;
    }

    bool intersecting(LineSegment other, Point &p) {
        if (is_horizontal() == other.is_horizontal())
            return false;
        if (is_horizontal()) {
            if (other.s.x <= s.x && other.t.x >= s.x &&
                    s.y <= other.s.y && t.y >= other.s.y) {
                p.x = s.x, p.y = other.s.y;
                return true;
            }
            return false;
        }
        else {
            if (s.x <= other.s.x && t.x >= other.s.x &&
                other.s.y <= s.y && other.t.y >= s.y) {
                p.x = other.s.x, p.y = s.y;
                return true;
            }
            return false;
        }
    }
};

int main() {
    int N;
    vector<LineSegment> lines;
    cin >> N;
    for (int i=0; i<N; i++) {
        LineSegment line;
        cin >> line.s.x >> line.s.y >> line.t.x >> line.t.y;
        lines.push_back(line);
    }

    for (int i=0; i<N; i++) {
        for (int j=i+1; j<N; j++) {
            Point p;
            if (lines[i].intersecting(lines[j], p))
                cout << '[' << p.x << ", " << p.y << ']' << endl;
        }
    }
}
