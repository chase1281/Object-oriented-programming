#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

vector<string> dict;
char puzzle[16][16];
int N;
vector<string> words;

int offset[8][2] = {{0,1}, {1,1},
                    {1,0}, {1,-1},
                    {0, -1}, {-1, -1},
                    {-1, 0}, {-1, 1} };
bool add_char_at(int x, int y, int dir, int dist, string &str) {
    int xx = x + dist*offset[dir][0];
    int yy = y + dist*offset[dir][1];
    if (xx < 0 || xx >= N || yy < 0 || yy >= N)
        return false;
    str += puzzle[xx][yy];
    return true;
}

void solve() {
    for (int i=0; i<N; i++) {
        for (int j = 0; j < N; j++) {
            for (int dir = 0; dir < 8; dir++) {
                string str = "";
                for (int k = 0; k < N; k++) {
                    if (add_char_at(i, j, dir, k, str)) {
                        if (find(dict.begin(), dict.end(), str) != dict.end()) {
                            if (find(words.begin(), words.end(), str) == words.end())
                                words.push_back(str);
                        }
                    }
                    else
                        break;
                }
            }
        }
    }

    for (auto w: words)
        cout << w << endl;
}

int main() {
    string word;
    ifstream dictfile("dictionary.txt");
    while(dictfile >> word)
        dict.push_back(word);
    dictfile.close();

    ifstream puzzfile("puzzle.txt");
    puzzfile >> N;
    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            puzzfile >> puzzle[i][j];
        }
    }
    puzzfile.close();
    solve();

    return 0;
}