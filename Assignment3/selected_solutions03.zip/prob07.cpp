#include <iostream>
using namespace std;

const int MAX = 100;

int board[MAX][MAX];
int n = 8;

void printBoard();
int countCapturableStone(int i, int j, int);
int countCapturableStoneInDir(int x, int y, int dir, int);
int getValue(int x, int y, int dir, int dist);
int putStone(int x, int y, int turn);
int captureStones(int x, int y, int dir, int turn);
int humanPlay();
int computerPlay();
void initBoard();
void decideWinner();

int main()
{
    int ch;
    while(1) {
        initBoard();
        printBoard();
        while(1) {
            int count = 0;
            count += humanPlay();
            printBoard();
            count += computerPlay();
            printBoard();
            if (count==0)
                break;
        }
        decideWinner();
        cout << "Do you want another game ? ";
        cin >> ch;
        if (ch != 'y' && ch != 'Y')
            break;
    }
}

void decideWinner() {
    int myCount = 0, computerCount = 0;
    for (int i=0; i<n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i][j] == 1) myCount++;
            else if (board[i][j] == 2) computerCount++;
        }
    }
    if (myCount > computerCount)
        cout << "Congraturation, You win !\n";
    else if (myCount < computerCount)
        cout << "Oops... you lost the game...\n";
    else
        cout << "Tie...\n";
}

void initBoard() {
    for (int i=0; i<n; i++)
        for (int j=0; j<n; j++)
            board[i][j] = 0;
    board[3][3] = 1;
    board[3][4] = 2;
    board[4][3] = 2;
    board[4][4] = 1;
}

int humanPlay()
{
    int x, y;
    do {
        cout << "Choose position: ";
        cin >> x >> y;
        if (x==-1 || y==-1)          // 착수 포기
            return 0;
    } while(countCapturableStone(x, y, 1) <= 0);

    return putStone(x, y, 1);
}

int computerPlay() {
    int max = 0, maxx, maxy;
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++) {
            if (board[i][j] != 0) continue;
            int count = countCapturableStone(i, j, 2);
            if( count > max) {
                max = count;
                maxx = i;
                maxy = j;
            }
        }
    }
    if (max <= 0)       // 착수포기
        return 0;
    return putStone(maxx, maxy, 2);
}

int putStone(int x, int y, int turn)
{
    int count = 0;
    for (int dir = 0; dir < 8; dir++) {
        if (countCapturableStoneInDir(x, y, dir, turn) > 0)
            count += captureStones(x, y, dir, turn);
    }
    board[x][y] = turn;
    return count;
}

int offset[8][2] = { {-1, 0}, {-1, 1}, {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1}};
int captureStones(int x, int y, int dir, int turn) {
    int count = 0;
    int opp = (turn == 1 ? 2 : 1);
    x += offset[dir][0];
    y += offset[dir][1];
    while(board[x][y] == opp)  {
        board[x][y] = turn;
        x += offset[dir][0];
        y += offset[dir][1];
        count++;
    }
    return count;
}

/* 위치 (x, y)에 turn의 돌을 놓았을 때 잡을 수 있는 상대 돌의 개수를 count하여 반환한다. */
int countCapturableStone(int x, int y, int turn)
{
    if (board[x][y] != 0)
        return 0;
    int sum = 0;
    for (int dir=0; dir<8; dir++) {
        sum += countCapturableStoneInDir(x, y, dir, turn);
    }
    return sum;
}

/* 위치 (x, y)에 turn의 돌을 놓았을 때 dir 방향으로 잡을 수 있는 상대 돌의 개수를 count하여 반환한다. */
int countCapturableStoneInDir(int x, int y, int dir, int turn) {
    int d=1, value;
    int opp = (turn == 1 ? 2 : 1);
    while((value = getValue(x,y,dir,d)) == opp)
        d++;
    return (value != turn ? 0 : d-1);
}

int getValue(int x, int y, int dir, int dist)
{
    int newx = x + dist*offset[dir][0];
    int newy = y + dist*offset[dir][1];
    if (newx<0 || newx >=n || newy < 0 || newy >= n)
        return -1;
    return board[newx][newy];
}

void printBoard() {
    printf("\n");
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++)
            cout << board[i][j] << ' ';
        cout << endl;
    }
}
