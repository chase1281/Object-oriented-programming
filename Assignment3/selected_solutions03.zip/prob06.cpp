#include <iostream>
#include <vector>
using namespace std;

class Point {
public:
    int x, y;
};

vector<vector<int>> offset{{0, 1}, {1, 0}, {0, -1}, {-1, 0}};

bool is_horizontal(Point s, Point t) {
    return s.x == t.x;
}

bool intersecting(Point s1, Point t1, Point s2, Point t2)  {
    if (is_horizontal(s1, t1) && s1.y > t1.y || !is_horizontal(s1, t1) && s1.x > t1.x)
        swap(s1, t1);
    if (is_horizontal(s2, t2) && s2.y > t2.y || !is_horizontal(s2, t2) && s2.x > t2.x)
        swap(s2, t2);

    if (is_horizontal(s1, t1) && is_horizontal(s2, t2))
        return !(s1.x != s2.x || t1.y > s2.y || t2.y > s1.y);
    else if (!is_horizontal(s1, t1) && !is_horizontal(s2, t2))
        return !(s1.y != s2.y || t1.x > s2.x || t2.x > s1.x);
    else if (is_horizontal(s1, t1))
        return s1.y <= s2.y && t1.y >= s2.y && s2.x <= s1.x && t2.x >= s1.x;
    else
        return s1.x <= s2.x && t1.x >= s2.x && s2.y <= s1.y && t2.y >= s1.y;
}

bool check_last(Point p, Point q, Point r) {
    if (is_horizontal(p, q) != is_horizontal(q, r))
        return true;
    if (is_horizontal(p, q) && (r.y > p.y && r.y < q.y || r.y > q.y && r.y < p.y
                    || p.y > q.y && p.y < r.y || p.y > r.y && p.y < q.y))
        return false;
    else if ((r.x > p.x && r.x < q.x || r.x > q.x && r.x < p.x
                    || p.x > q.x && p.x < r.x || p.x > r.x && p.x < q.x))   // both vertical
        return false;
    return true;
}

bool is_valid_move(vector<Point> &points, Point &p) {
    for (auto i=0; i<(int)points.size()-2; i++) {
        if (intersecting(points[i], points[i+1], points[points.size()-1], p))
            return false;
    }
    if (points.size() > 1) {
        return check_last(points[points.size()-2], points[points.size()-1], p);
    }
    return true;
}

int main() {
    vector<Point> points;
    Point cur;
    cur.x = 0, cur.y = 0;
    points.push_back(cur);
    while(1) {
        int dir, len;
        cin >> dir >> len;
        if (dir==-1 && len==-1)
            break;
        Point next;
        next.x = cur.x + len*offset[dir][0];
        next.y = cur.y + len*offset[dir][1];

        if (is_valid_move(points, next)) {
            cout << next.x << " " << next.y << endl;
            points.push_back(next);
            cur = next;
        }
        else
            cout << "invalid move" << endl;
    }
}