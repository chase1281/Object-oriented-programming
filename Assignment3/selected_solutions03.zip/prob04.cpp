#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

int N;
vector<vector<int>> board;

bool check(int x, int y);

int main()
{
    ifstream infile("board.txt");
    infile >> N;
    for (int i=0; i<N; i++) {
        vector<int> row(N);
        board.push_back(row);
        for (int j = 0; j<N; j++)
            infile >> board[i][j];
    }
    infile.close();

    for (int i=0; i<N; i++) {
        for (int j=0; j<N; j++) {
            if (board[i][j] == 0)
                continue;

            // check if board[i][j] is an end of 5-consecutive stone of same color
            if (check(i, j)) {
                if (board[i][j] == 1)
                    cout << "black";
                else
                    cout << "white";
                return 0;
            }
        }

    }
    cout << "not finished";
    return 0;
}

vector<vector<int>> offset{
        {1, -1},
        {1, 0},
        {1, 1},
        {0, 1}
};

bool check(int x, int y) {
    // check four directions, SW, S, SE, E
    int mystone = board[x][y];
    for (int dir=0; dir<4; dir++) {
        int d = 1;
        while (d<5 && x + d*offset[dir][0] < N
               && y + d*offset[dir][1] >= 0
               && y + d*offset[dir][1] < N) {
            if (board[x+d*offset[dir][0]][y+d*offset[dir][1]] != mystone)
                break;
            d++;
        }
        if (d == 5)
            return true;
    }
    return false;
}
