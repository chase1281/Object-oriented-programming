#include <iostream>
#include <sstream>
#include <string>
#include <cctype>
using namespace std;

int main() {
    string line;
    while(1) {
        getline(cin, line);
        if (line == "exit") break;
        for (int i=0; i<line.length();) {
            if (isspace(line[i]) && (i==0 || isspace(line[i-1])))
                line.erase(i, 1);
            else
                i++;
        }
        if (isspace(line[line.length()-1]))
            line.erase(line.length()-1, 1);

        cout << line << ":" << line.length() << endl;
    }

    return 0;
}



//int main() {
//    string line;
//
//    while(1) {
//        getline(cin, line);
//        if (line == "exit") break;
//        int k=0;
//        stringstream ss;
//        for (int i=0; i<line.length(); i++) {
//            if (!isspace(line[i]) || i>0 && !isspace(line[i-1]))
//                ss << line[i], k++;
//        }
//        if ()
//        ss << ":" << k;
//        cout << ss.str() << endl;
//    }
//
//    return 0;
//}

//int main() {
//    string line;
//
//    while(1) {
//        getline(cin, line);
//        if (line == "exit") break;
//        auto it = line.begin();
//        while(it!=line.end()) {
//            if (isspace(*it) && (it==line.begin() || isspace(*(it-1)))) {
//                it = line.erase(it);
//            }
//            else
//                it++;
//        }
//        if (isspace(*(it-1)))
//            line.erase(it-1);
//        cout << line << ":" << line.length() << endl;
//    }
//
//    return 0;
//}
