#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
vector<string> words;

int len_common_prefix(string a, string b) {
    for (int i=0; i<min(a.length(), b.length()); i++)
        if (a[i] != b[i])
            return i;
    return min(a.length(), b.length());
}

int main() {
    string str;
    int n;
    cin >> n;
    for (int i=0; i<n; i++) {
        cin >> str;
        words.push_back(str);
    }
    string prefix = words[0];
    int len = prefix.length();
    for (int i=1; i<n && len > 0; i++) {
        int len = len_common_prefix(prefix, words[i]);
        prefix = prefix.substr(0, len);
    }
    cout << prefix;
    return 0;
}

