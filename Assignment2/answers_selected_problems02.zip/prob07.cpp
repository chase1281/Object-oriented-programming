#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
vector<string> words;

int main() {
    string str;
    while(1) {
        cin >> str;
        if (str == "exit") break;
        auto it = words.begin();
        while(it != words.end() && *it < str)
            it++;
        if (it != words.end() && *it==str) {
            cout << "duplicate" << endl;
            continue;
        }
        words.insert(it, str);
        for (auto w: words)
            cout << w << ' ';
        cout << endl;
    }

    return 0;
}
