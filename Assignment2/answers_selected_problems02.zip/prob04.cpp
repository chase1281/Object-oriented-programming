#include <iostream>
#include <string>
using namespace std;
int main() {
    string s;
    getline(cin, s);
    int sum = 0, start = 0, pos = 0;
    if (s[0] == '+' || s[0] == '-')
        pos = 1;
    while(true) {
        int idx = s.find_first_of("+-", pos);
        if(idx == -1) {
            string part = s.substr(start);
            if(part == "") break;
            sum += stoi(part);
            break;
        }
        int count = idx - start;
        string part = s.substr(start, count);
        sum += stoi(part);
        pos = idx+1;
        start = idx;
    }
    cout << "The sum is " << sum << endl;
    return 0;
}