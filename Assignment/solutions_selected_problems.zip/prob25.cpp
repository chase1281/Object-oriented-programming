#include <iostream>
using namespace std;
const int MAX = 100;

int main() {
    int N, data[MAX];
    cin >> N;
    for (int i=0; i<N; i++)
        cin >> data[i];
    for (int i=N-1; i>0; i--) {
        for (int j=0; j<i; j++) {
            if (data[j] > data[j+1]) {
                int tmp = data[j];
                data[j] = data[j+1];
                data[j+1] = tmp;
            }
        }
    }
    int k=0;
    for (int i=1; i<N; i++) {
        if (data[i] != data[i-1]) {
            data[++k] = data[i];
        }
    }
    cout << k+1 << ":";
    for (int i=0; i<=k; i++)
        cout << data[i] << " ";
    return 0;
}