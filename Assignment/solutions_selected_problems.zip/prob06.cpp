#include <iostream>
using namespace std;

int main() {
    int n, k;
    cin >> n;
    cin >> k;
    int min = k, max = k;
    cout << max-min << " ";
    for (int i=1; i<n; i++) {
        cin >> k;
        if (k>max) max=k;
        if (k<min) min=k;
        cout << max-min << " ";
    }
    return 0;
}

