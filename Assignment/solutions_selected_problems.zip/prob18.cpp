#include <iostream>
using namespace std;

int main() {
    int N;
    int count[10] = { 0 };
    cin >> N;
    while(N > 0) {
        count[N%10]++;
        N /= 10;
    }
    for (int c: count)
        cout << c << " ";
    return 0;
}