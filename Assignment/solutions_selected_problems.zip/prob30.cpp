#include <iostream>
using namespace std;
const int MAX = 100;

int calc_overlap(int s1, int t1, int s2, int t2) {
    if (t1 <= s2 || t2 <= s1)
        return 0;
    return min(t1, t2) - max(s1, s2);
}

int main() {
    int s[MAX], t[MAX], N;
    cin >> N;
    for (int i=0; i<N; i++)
        cin >> s[i] >> t[i];

    int max_len_overlap = 0;
    int max_i = 0, max_j = 0;
    for (int i=0; i<N; i++) {
        for (int j=i+1; j<N; j++) {
            int len = calc_overlap(s[i], t[i], s[j], t[j]);
            if (len > max_len_overlap) {
                max_len_overlap = len;
                max_i = i, max_j = j;
            }
        }
    }
    cout << s[max_i] << " " << t[max_i] << " " << s[max_j] << " " << t[max_j];
    return 0;
}
