#include <iostream>
using namespace std;
const int MAX = 100;

int main() {
    int data[MAX], k, n=0;
    while(1) {
        cin >> k;
        if (k == -1)
            break;
        data[n++] = k;
    }
    int gain = 0;
    int total_gain = 0;
    for (int i=1; i<n; i++) {
        if (data[i] >= data[i-1])
            gain += (data[i]-data[i-1]);
        else {
            total_gain += gain;
            gain = 0;
        }
    }
    cout << total_gain+gain;

    return 0;
}