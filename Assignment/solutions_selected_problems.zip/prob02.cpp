#include <iostream>
using namespace std;

int main() {
    int n, denom = 1, sign=1;
    cin >> n;
    double sum = 0;
    for (int i=0; i<=n; i++) {
        sum += sign*1.0/denom;
        denom *= 2;
        sign *= -1;
    }
    cout << sum << endl;
    return 0;
}
