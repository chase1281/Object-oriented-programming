#include <iostream>
using namespace std;

int main() {
    int flags[14] = { 0 };
    int k;
    for (int i=0; i<7; i++) {
        cin >> k;
        flags[k] = 1;
    }
    int count = 0;
    for (int i=1; i<=13; i++) {
        if (flags[i])
            count++;
        else
            count = 0;
        if (count == 5) {
            cout << "YES";
            return 0;
        }
    }
    cout << "NO";
    return 0;
}