#include <iostream>
using namespace std;

int main() {
    int n, denom = 1;
    cin >> n;
    double sum = 0;
    for (int i=1; i<=n; i++) {
        denom *= i;
        sum += 1.0/denom;
    }
    cout << sum << endl;
    return 0;
}

