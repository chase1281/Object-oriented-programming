#include <iostream>
using namespace std;

int main() {
    int n, k;
    cin >> n;
    int positive_min = -1;
    for (int i=0; i<n; i++) {
        cin >> k;
        if (k >= 0 && (positive_min == -1 || k < positive_min))
            positive_min = k;
    }
    cout << positive_min << endl;
    return 0;
}

