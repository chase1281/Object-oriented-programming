#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand((unsigned int) time(NULL));
    int succ1 = 0, succ2 = 0;
    for (int t=0; t<1000000; t++) {
        int count1 = 0;
        for (int i=0; i<6; i++) {
            if (rand()%6==0) {
                count1++;
                break;
            }
        }
        if (count1 > 0)
            succ1++;

        int count2 = 0;
        for (int i=0; i<12; i++) {
            if (rand()%6==0)
                count2++;
        }
        if (count2 > 1)
            succ2++;
    }
    cout << succ1/1000000.0 << " " << succ2/1000000.0 << endl;
    return 0;
}