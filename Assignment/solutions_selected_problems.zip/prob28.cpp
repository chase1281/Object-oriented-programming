#include <iostream>
using namespace std;

const int MAX = 100;

int main() {
    int N, num[MAX];
    cin >> N;
    for (int i=0; i<N; i++)
        cin >> num[i];

    int max_len = 1, len=1;
    for (int i=1; i<N; i++) {
        if (num[i] >= num[i-1])
            len++;
        else
            len=1;
        if (len > max_len)
            max_len = len;
    }
    cout << max_len;
    return 0;
}