#include <iostream>
using namespace std;

int main() {
    int data[100];
    int n=0, k;
    while(true) {
        cin >> k;
        if (k==-1) break;
        data[n++] = k;
    }
    int count = 0;
    if (data[0] <= data[1])
        count++;
    for (int i=1; i<n-1; i++) {
        if (data[i-1] <= data[i] && data[i] <= data[i+1])
            count++;
    }
    if (data[n-2] <= data[n-1])
        count++;
    cout << count;
    return 0;
}