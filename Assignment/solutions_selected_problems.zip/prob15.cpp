#include <iostream>
using namespace std;

int main() {
    int count = 0, N;
    cin >> N;
    for (int i=1; i<=N; i++) {
        int k=i;
        while (k>0) {
            if (k%10 == 0) count++;
            k /= 10;
        }
    }
    cout << count;
    return 0;
}