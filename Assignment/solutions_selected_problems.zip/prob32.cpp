#include <iostream>
using namespace std;
const int MAX = 100;

int main() {
    int seq[MAX], N;
    int forward[MAX] = { 0 }, backward[MAX] = { 0 };
    cin >> N;
    for (int i=0; i<N; i++)
        cin >> seq[i];
    for (int i=1; i<N; i++) {
        if (seq[i - 1] == 0)
            forward[i] = 0;
        else
            forward[i] = forward[i - 1] + 1;
    }
    for (int i=N-2; i>=0; i--) {
        if (seq[i + 1] == 0)
            backward[i] = 0;
        else
            backward[i] = backward[i + 1] + 1;
    }
    int max = 0;
    for (int i=0; i<N; i++) {
        if (forward[i]+backward[i] + 1 > max)
            max = forward[i]+backward[i] + 1;
    }
    cout << max;
    return 0;
}
