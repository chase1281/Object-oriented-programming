#include <iostream>
using namespace std;

bool rel_prime(int a, int b) {
    int small = min(a, b);
    for (int i=2; i<=small; i++) {
        if (a%i ==0 && b%i==0)
            return false;
    }
    return true;
}

int main() {
    int count = 0;
    for (int i=2; i<=100; i++) {
        for (int j=i+1; j<=100; j++) {
            for (int k=j+1; k<=100; k++) {
                if (rel_prime(i, j) && rel_prime(j, k) && rel_prime(i, k))
                    count++;
            }
        }
    }
    cout << count;
}
