#include <iostream>
using namespace std;

int main() {
    int count = 0;
    for (int x=0; x<=100; x++) {
        for (int y=0; y<=100; y++) {
            if (y <= 2.0/3*x && y >= 1.0/3*x && x*x+y*y <= 10000)
                count++;
        }
    }
    cout << count;
}