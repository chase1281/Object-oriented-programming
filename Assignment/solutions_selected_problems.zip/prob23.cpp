#include <iostream>
using namespace std;
const int MAX = 100;

int main() {
    int n = 0, t;
    int data[MAX];
    while (1) {
        cin >> t;
        if (t==-1) break;
        bool duplicate = false;
        for (int i=0; i<n; i++) {
            if (data[i] == t) {
                cout << "duplicate" << endl;
                duplicate = true;
                break;
            }
        }
        if(duplicate)
            continue;
        n++;
        int j = n-1;
        while (j>=0 && data[j]>t) {
            data[j+1] = data[j];
            j--;
        }
        data[j+1] = t;
        for (int k=0; k<n; k++)
            cout << data[k] << " ";
        cout << endl;
    }
    return 0;
}