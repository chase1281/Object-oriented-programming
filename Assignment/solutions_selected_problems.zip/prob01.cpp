#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;
    int prev1 = 1, prev2 = 1, cur;
    for (int i=2; i<=n; i++) {
        cur = prev1 + prev2;
        prev2 = prev1;
        prev1 = cur;
    }
    cout << cur;
    return 0;
}
